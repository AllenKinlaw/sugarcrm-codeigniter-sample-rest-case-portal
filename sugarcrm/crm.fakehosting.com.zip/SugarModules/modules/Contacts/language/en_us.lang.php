<?php 
 // created: 2013-03-20 18:16:12
$mod_strings['LBL_CNUMBER'] = 'Customer Number';

?>
