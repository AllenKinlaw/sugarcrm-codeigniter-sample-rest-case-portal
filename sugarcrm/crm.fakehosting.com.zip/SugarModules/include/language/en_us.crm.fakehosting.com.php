<?php 
$app_list_strings['case_type_dom'] = array (
  '' => '',
  'Support' => 'Support',
  'Announcement' => 'Announcement',
);